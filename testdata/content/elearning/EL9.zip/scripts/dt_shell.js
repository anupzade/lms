/*
(c)Datatask Pty. Ltd. 2001 - 2004. All rights reserved. The copy or
reproduction of any material contained is strictly prohibited unless
with the express consent of Datatask Pty Ltd. This material is protected
under Australian and international copyright law. Unauthorised
reproduction or distribution may result in civil or criminal penalties.
*/

//document.domain = document.domain.substring(document.domain.indexOf('.') + 1);

var already_notified = false;
//
function searchForApi(win, up_limit, down_limit, ex_win)
{
  // Search ourselves
  var api_win = (win.API != null) ? win : null;
  // Search our parents (within limits)
  if ((api_win == null) && (up_limit > 0) && (win.parent != win) && (win.parent != null)) 
    api_win = searchForApi(win.parent, (up_limit-1), down_limit, win);
  // Search our child windows (within limits)
  if ((api_win == null) && (down_limit > 0))
  {
    for ( var fr_no = 0; ((fr_no < win.frames.length) && (api_win == null)); ++fr_no )
    {
      // Don't search the child where the request came from (ex_win)
      if (win.frames[fr_no].window != ex_win)
        api_win = searchForApi(win.frames[fr_no].window, 0, (down_limit-1), win);
    }
  }
  // Search our opener windows (within limits)
  if ((api_win == null) && (up_limit > 0) && (win.opener != null) && typeof(win.opener != "undefined"))
    api_win = searchForApi(win.opener, (up_limit-1), down_limit, win);
  // Return the results
  return api_win;
}
//
function findAPI()
{
  // Search just the parents
  var api_win = searchForApi(window, 10, 0, null);
  // Search our siblings and our parents and their siblings
  if (api_win == null)
    api_win = searchForApi(window, 10, 1, null);
  // Search our children and our parents children  (search far and wide)
  if (api_win == null)
    api_win = searchForApi(window, 20, 7, null);
  // Return our results
  return api_win;
}

//----- Initialisation code for the page.
var api_win = findAPI();
var api_object = (api_win != null) ? api_win.API : null;
var movie_object = null;
var initialised = false;

//----- Functions.
function warning_window()
{
  var xpos = 0, ypos = 0; // Assume 640 x 480 screen dimensions.
  var width = 300, height = 150;
  if ( window.screen )
  {
    xpos = ( window.screen.availWidth - width ) / 2;
    ypos = ( window.screen.availHeight - height ) / 2;
    if ( xpos < 0 )
      xpos = 0;
    if ( ypos < 0 )
      ypos = 0;
  }

  wwin = window.open('', '_blank', 'toolbar=no,location=no,resizable=yes,directories=no,status=no,scrollbars=no,menubar=no,width=' + width + ',height=' + height + ',left=' + xpos + ',top=' + ypos + ',screenX=' + xpos + ',screenY=' + ypos);
  wwin.document.open('text/html');
  wwin.document.writeln('<html><head><title>WARNING</title></head>');
  wwin.document.writeln('<body><p>In the future you must leave the lesson via the courseware navigation bar, not the button on the title bar or ALT-F4.</p>');
  wwin.document.writeln('<p><b>Courseware results have been lost.</b></p></body></html>');
  wwin.document.close();
}

function page_OnUnload()
{

  if (window.opener && window.opener.closed)
		return;

  // If still initialised, display the warning window to indicate that we
  // must shut-down via the lesson.
  if ( initialised == true )
  {
   // if ( ! already_notified )
     // warning_window();

    if ( api_object != null )
      api_object.LMSFinish("");
  }

	// Close opener window if it looks like it was opened by another window.
	if (( window.opener != null ) &&  ( window.opener != window ) &&  ( ! window.opener.closed )) {
		if (( window.opener.parent == null ) ||  ( window.opener.parent == window.opener )) {
			window.opener.close();
		}
	}
}

function page_OnBeforeUnload()
{
  if (window.opener && window.opener.closed)
		return;
	
	// If still initialised, try asking the courseware to finish up nicely.
  if ( initialised == true )
  {
    already_notified = true;
    event.returnValue = 'To bookmark this page click on the Bookmark button on the course navigation bar.  ';
  }
}

//----- Flash Interface utility functions.
// Sets error variables in the flash movie to indicate that there is no LMS API.
// Set the result return variable
function setResult( result )
{
  if ( movie_object != null )
  {
    result = new String(result); // In case the LMS returns a boolean instead of a string.
    movie_object.SetVariable("LMSResult", result);
  }
}

// Set error return variables
function setErrorStrings( error_code, error_string, diag )
{
  if ( movie_object != null )
  {
    movie_object.SetVariable("LMSErrorCode", error_code);
    movie_object.SetVariable("LMSErrorString", error_string);
    movie_object.SetVariable("LMSDiag", diag);
  }
}

function noAPI( result )
{
  if ( movie_object != null )
  {
    setResult(result);
    setErrorStrings("101", "No LMS API found."
    , "The LMS API could not be located.");
  }
}

function setErrors()
{
  if ( movie_object == null )
    return "101";

  if ( api_object == null )
  {
    noAPI("false");
    return "101";
  }

  var error_code = api_object.LMSGetLastError();
  if ( error_code == "0" )
  {
    setErrorStrings("0", "No error.", "");
  }
  else
  {
    setErrorStrings(error_code, api_object.LMSGetErrorString(error_code), api_object.LMSGetDiagnostic(error_code));
  }
  return error_code;
}

//----- The actual LMS calls made from the Flash movie
function doLMSInitialise()
{
  if ( api_object == null )
    api_object = findAPI();
  if ( api_object == null )
    noAPI("false");
  else
  {
    setResult(api_object.LMSInitialize(""));
    if ( setErrors() == "0" )
      initialised = true;
  }
}

function doLMSFinish()
{
  if ( api_object == null )
    noAPI("false");
  else
  {
    setResult(api_object.LMSFinish(""));
   // if ( setErrors() == "0" )
      initialised = false;
  }
}

function doLMSGetLocation()
{
	
//	alert("location");
	var str =api_object.LMSGetValue("cmi.core.lesson_location");
	//if(window.movie_object) window.document["movie_object"].SetVariable("current", str);
	//if(document.movie_object) document.movie_object.SetVariable("current", str);
	//alert("location "+str);	
}

function doLMSGetValue( args )
{
  if ( args == "datatrain.score.normalise" )
  {
    setResult("true");
    setErrorStrings("0", "No error.", "");
    return;
  }

  if ( api_object == null )
    noAPI("");
  else
  {
    setResult(api_object.LMSGetValue(args));
    setErrors();
  }
}

function doLMSSetValue( args )
{
	
  if ( api_object == null )
    noAPI("false");
  else
  {
    args = new String(args); // Needed for Netscape.
    if ( args == "" )
    {
      setResult("false");
      setErrorStrings("401", "Not implemented.", "No argument specified.");
      return;
    }

    var pos = args.indexOf(":");
    if ( pos < 0 )
    {
      setResult("false");
      setErrorStrings("401", "Not implemented.", "Bad argument '" + args + "'.");
      return;
    }
    var var_name = args.substring(0, pos);
    var var_value = args.substring(pos + 1, args.length);

    // The following code retains a lesson status of completed or passed if it
    // is already set.
    if (( var_name  == "cmi.core.lesson_status" )
    &&  ( var_value != "completed" ))
    {
      var current_status = api_object.LMSGetValue(var_name);
	//alert(current_status+" : current_status : "+var_value)
      if (( current_status != "completed" )
      &&  ( current_status != "passed" ))
      {
	setResult(api_object.LMSSetValue(var_name, var_value));
	setErrors();
      }
    }
    else
    {	
      setResult(api_object.LMSSetValue(var_name, var_value));
      setErrors();
    }
  }
}

function doLMSCommit()
{
  if ( api_object == null )
    noAPI("false");
  else
  {
    setResult(api_object.LMSCommit(""));
    setErrors();
  }
}

function doGotLMS()
{
  if ( api_object == null )
    api_object = findAPI();
  if ( api_object == null )
    noAPI("false");
  else
  {
    setResult("true");
    setErrorStrings("0", "No error.", "");
  }
}

function doLoadScript( args )
{
	alert("do Load SCript");
  var movie_name = null;
  args = new String(args); // Needed for Netscape.
  arg_array = args.split(";");
  if ( arg_array.length >= 1 )
    movie_name = arg_array[0];
  if (( movie_name != null ) && ( movie_name == '' ))
    movie_name = null;
  if (( movie_name != null ) && ( movie_object != null ))
  {
    movie_object.SetVariable(movie_name + ".sim_line1"
    , " Facilities for running simulator scripts under this module");
    movie_object.SetVariable(movie_name + ".sim_line2"
    , " are not available.");
    movie_object.SetVariable(movie_name + ".sim_line4"
    , " Please contact your supplier with the details of this module.");
    movie_object.SetVariable(movie_name + ".simulation_finish.raw", "0");
    movie_object.SetVariable(movie_name + ".simulation_finish.max", "0");
    movie_object.TPlay(movie_name + ".simulation_finish");
  }
}

function doFocusSimAPI()
{
  // No action required
}

function doScriptBookmark()
{
  // No action required
}

function doquit()
{
  window.close();
}

var InternetExplorer = navigator.appName.indexOf("Microsoft") != -1;

// Handle all the the FSCommand messages in a Flash movie
function module_DoFSCommand( cmd, args )
{	
  if ( movie_object == null )
    movie_object = thisMovie(movieName);

  if ( cmd == "LMSInitialize" )
    doLMSInitialise();
  else if ( cmd == "LMSInitialise" )
    doLMSInitialise();
  else if ( cmd == "LMSFinish" )
    doLMSFinish();
  else if ( cmd == "LMSGetValue" )
    doLMSGetValue(args);
  else if ( cmd == "LMSSetValue" )
    doLMSSetValue(args);
  else if ( cmd == "LMSCommit" )
    doLMSCommit();
  else if ( cmd == "GotLMS" )
    doGotLMS();
  else if ( cmd == "LoadScript" )
    doLoadScript(args);
  else if ( cmd == "FocusSimAPI" )
    doFocusSimAPI();
  else if ( cmd == "ScriptBookmark" )
    doScriptBookmark();
  else if ( cmd == "quit" )
    doquit();
  else if ( cmd == "sendvaluetoflash" )
	sendvaluetoflash();
  else if ( cmd == "sendvaluetojava" )
	sendvaluetojava(args);
  else if(cmd == 'openwindow')
  window.open('sco01/swf/print.html','print','left=0,top=0,width=1,height=1');
  else
	if(cmd == "doLMSGetLocation")
	doLMSGetLocation();
   else
    alert("Warning: Unknown command '" + cmd + "' received from courseware.");
}

// Hook for Internet Explorer 
if (navigator.appName && navigator.appName.indexOf("Microsoft") != -1 && 
	  navigator.userAgent.indexOf("Windows") != -1 && navigator.userAgent.indexOf("Windows 3.1") == -1)
{
	document.write('<');
	document.write('SCRIPT LANGUAGE=VBScript\> \n');
	document.write('on error resume next \n');
	document.write('Sub module_FSCommand(ByVal command, ByVal args)\n');
	document.write('  call module_DoFSCommand(command, args)\n');
	document.write('end sub\n');
	document.write('</SCRIPT\> \n');
}

function focusMovie() {
	if ( movie_object == null )
		movie_object = thisMovie(movieName);
	if ( InternetExplorer && ( movie_object != null ))
		movie_object.focus();
}
<!-- added function -->
var movieName = "module";
function thisMovie(movieName) 
{
	if (navigator.appName.indexOf ("Microsoft") !=-1) 
	{
		return window[movieName]
	}	
	else 
	{
		return document.embeds[movieName]
	}
}
function sendvaluetoflash()
{	
//	alert("test"+lastvisit);
	thisMovie(movieName).SetVariable('current',lastvisit);
}
function sendvaluetojava(num)
{
	lastbookmark = num;
	cpage= num;
	if(API)
	{
		API.d_lesson_idx=num;		
		API.d_location=num;
	}
	if(total==num)
	{
		if(API)
		{
			API.d_status='completed';
		}
		initStatus='completed';
	}	

}
function closewindow(num)
{
	/*if(num=='' || num=='undefined') num=1;			//New Code Aug172007
 
	 
	if(chkStatus==false)//New Code Aug172007
	{
		if(API)
		{					
			if(initStatus == "completed" || initStatus == "passed") 
			{
				API.d_status=initStatus;						
			} 
			else
			{
				if(total == num) 					
				{
					API.d_status='completed';
				}
				else if((total != num) && (initStatus=="incomplete"))	
				{
					API.d_status='incomplete';
				}
				else if((total != num) && (initStatus=="completed"))	
				{
					API.d_status='completed';
				}
			}
			chkStatus=true
			API.d_lesson_idx=Number(num);
			API.d_location=Number(num);	
			API.finishCourse();
		}
	}*/
}
function closecoursewindow()
{
	var brows=navigator.appName;
	if((brows.toLowerCase()=="microsoft internet explorer") || (brows.toLowerCase()=="ie"))
	{
		top.window.close();
	}
	else
	{
		top.close();
	}
}		
